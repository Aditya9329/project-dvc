from setuptools import setup, find_packages

setup(
    name = "src", 
    version="0.0.1",
    description="Its a wine 0 package",
    author="Aditya9329",
    packages = find_packages(),
    license="MIT"
)