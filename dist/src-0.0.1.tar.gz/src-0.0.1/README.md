create env
    ```bash
    conda create -n winequaltiy
    ```


    activate
    ```bash
    conda activate winequaltiy
    ```

    create a req file
    install the req
    ```bash
    pip install -r req
    ```


    after gathering data

    git init

    dvc init

    dvc add data_given/winequality-red.csv

    git add . 
    git commit -m "first commit"

    